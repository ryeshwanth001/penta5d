import catalog from "../../products.json";
export async function onRequestPost({ request, env }) {
  if (!env.RAZORPAY_KEY_ID || !env.RAZORPAY_KEY_SECRET) return Response.json({error:"Online payment is not configured yet. The site owner must add Razorpay API credentials in Cloudflare Pages settings."},{status:503});
  let body; try { body=await request.json(); } catch { return Response.json({error:"Invalid request."},{status:400}); }
  const items=body.items; const customer=body.customer;
  if (!Array.isArray(items)||items.length<1||items.length>30||!customer||!customer.name||!customer.email||!customer.phone||!customer.address) return Response.json({error:"Please provide valid items and delivery details."},{status:400});
  let amount=0; const receiptItems=[];
  for (const item of items) {
    const product=catalog.find(p=>p.id===item.id); const quantity=Number(item.quantity);
    if (!product||!Number.isInteger(quantity)||quantity<1||quantity>20) return Response.json({error:"Invalid product or quantity."},{status:400});
    amount+=product.price*quantity; receiptItems.push({id:product.id,name:product.name,quantity,unit_price:product.price});
  }
  if (amount<1||amount>500000) return Response.json({error:"Order total is outside the supported range."},{status:400});
  const auth=btoa(`${env.RAZORPAY_KEY_ID}:${env.RAZORPAY_KEY_SECRET}`);
  const response=await fetch("https://api.razorpay.com/v1/orders",{method:"POST",headers:{Authorization:`Basic ${auth}`,"Content-Type":"application/json"},body:JSON.stringify({amount:amount*100,currency:"INR",receipt:`p5d_${Date.now()}`,notes:{customer_name:String(customer.name).slice(0,100),customer_email:String(customer.email).slice(0,100),customer_phone:String(customer.phone).slice(0,30),delivery_address:String(customer.address).slice(0,500),items:JSON.stringify(receiptItems).slice(0,500) }})});
  const order=await response.json(); if(!response.ok||!order.id) return Response.json({error:"Payment provider could not create an order. Please try again later."},{status:502});
  return Response.json({orderId:order.id,amount:order.amount,currency:order.currency,keyId:env.RAZORPAY_KEY_ID},{headers:{"Cache-Control":"no-store"}});
}
