export async function onRequestPost({ request, env }) {
  if (!env.RAZORPAY_KEY_SECRET) return Response.json({error:"Payment verification is not configured."},{status:503});
  let body; try { body=await request.json(); } catch { return Response.json({error:"Invalid request."},{status:400}); }
  const {razorpay_order_id,razorpay_payment_id,razorpay_signature,orderId}=body;
  if (!razorpay_order_id||!razorpay_payment_id||!razorpay_signature||orderId!==razorpay_order_id) return Response.json({verified:false,error:"Missing or mismatched payment details."},{status:400});
  const key=await crypto.subtle.importKey("raw",new TextEncoder().encode(env.RAZORPAY_KEY_SECRET),{name:"HMAC",hash:"SHA-256"},false,["sign"]);
  const signed=await crypto.subtle.sign("HMAC",key,new TextEncoder().encode(`${razorpay_order_id}|${razorpay_payment_id}`));
  const expected=[...new Uint8Array(signed)].map(b=>b.toString(16).padStart(2,"0")).join("");
  if(expected.length!==razorpay_signature.length) return Response.json({verified:false},{status:400});
  let diff=0; for(let i=0;i<expected.length;i++) diff|=expected.charCodeAt(i)^razorpay_signature.charCodeAt(i);
  if(diff!==0) return Response.json({verified:false},{status:400});
  return Response.json({verified:true,orderId:razorpay_order_id,paymentId:razorpay_payment_id},{headers:{"Cache-Control":"no-store"}});
}
