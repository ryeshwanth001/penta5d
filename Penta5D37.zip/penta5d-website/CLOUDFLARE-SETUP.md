# PENTA 5D — Cloudflare Pages & Razorpay setup

## Deploy to Cloudflare Pages
1. Extract this ZIP. In Cloudflare Dashboard, open **Workers & Pages → Create → Pages → Upload assets** (Direct Upload), and upload the contents of the `penta5d-website` folder. For Git integration, push the folder to a repository and connect it as a Pages project. The `/functions` directory must be deployed through a Git-integrated Pages project or Wrangler; static Direct Upload alone does **not** deploy Pages Functions.
2. Recommended: connect the folder to a Git repository so Cloudflare deploys the `functions/api` routes. Set the build command to blank / no build, and output directory to `.`.
3. In Pages project **Settings → Variables and Secrets**, add encrypted secrets `RAZORPAY_KEY_ID` and `RAZORPAY_KEY_SECRET` from your Razorpay account. Never put the secret in HTML or commit it to Git. Redeploy after adding secrets.
4. Start with Razorpay Test Mode keys and test a complete checkout before switching to Live Mode. Complete any account/KYC activation required by Razorpay.

## Important payment notes
- The storefront has an add-to-cart flow and Razorpay checkout integration. Real online payment requires the server-side Pages Functions and valid Razorpay credentials; checkout intentionally returns a setup message until configured.
- Prices are validated against `products.json` on the server, not trusted from the browser.
- Configure and test order fulfillment, delivery charges, taxes, cancellation/refund policy, privacy policy and terms before accepting live payments. Consider adding a Razorpay webhook for asynchronous payment status and order fulfilment. A successful browser signature verification is not, by itself, a complete order management/fulfilment system.
- Existing prices from the sample site are used. Review every product price and stock availability before launch.

## Project contents
- `index.html`: responsive storefront, animations, shopping cart and checkout
- `products/`, `images/`: existing sample product photos and logo
- `products.json`: catalog used for server-side amount validation
- `functions/api/create-order.js`: creates Razorpay orders securely
- `functions/api/verify-payment.js`: verifies Razorpay payment signature
