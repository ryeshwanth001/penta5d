# PENTA 5D – Final Website

Professional single-page website for your 3D printing business.

## Founders
- **Yeshwanth.R** – Co-founder / CEO  
- **Devarsha.S** – Founder / CFO  

## How to Preview (Very Important)

### On iPhone / iPad (iOS)
1. Download the zip file
2. Open the **Files** app
3. Go to **Downloads**
4. Tap the zip → tap **Preview Content** or **Extract**
5. Open the folder **penta5d-website**
6. Tap **index.html**
7. Choose **Safari** (or Chrome) to open

### On Computer
1. Extract the zip
2. Open the folder `penta5d-website`
3. Double-click `index.html`

The website works completely offline after opening.

---

## What’s Included

- Clean modern design (mobile-friendly)
- Company logo
- 73 product photos with descriptions
- WhatsApp links (Primary: 8072941091 | Alternate: 6379634882)
- Floating WhatsApp button
- Inquiry buttons on every product
- Instagram link (penta5d)
- About section with founders names
- Contact section

## Folder Structure

```
penta5d-website/
├── index.html          ← Open this file
├── images/
│   └── logo.jpg
├── products/           ← All 73 product photos
└── README.md
```

## How to Add More Photos Later

1. Put new photos inside the `products/` folder
2. Tell me the photo names + product title
3. I will update the website for you

## Hosting (When Ready)

Upload the whole `penta5d-website` folder to:
- Netlify (easiest)
- Vercel
- GitHub Pages

Then you will get a real website link to share.

Need any change? Just message me!
